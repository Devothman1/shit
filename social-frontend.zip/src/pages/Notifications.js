import React from 'react';
function Notifications() {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold">Notifications Page</h1>
      <p>Welcome to the Notifications page of your Social App!</p>
    </div>
  );
}
export default Notifications;
