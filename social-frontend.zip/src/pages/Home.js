import React from 'react';
function Home() {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold">Home Page</h1>
      <p>Welcome to the Home page of your Social App!</p>
    </div>
  );
}
export default Home;
