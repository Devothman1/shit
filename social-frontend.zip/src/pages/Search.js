import React from 'react';
function Search() {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold">Search Page</h1>
      <p>Welcome to the Search page of your Social App!</p>
    </div>
  );
}
export default Search;
