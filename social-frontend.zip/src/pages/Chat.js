import React from 'react';
function Chat() {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold">Chat Page</h1>
      <p>Welcome to the Chat page of your Social App!</p>
    </div>
  );
}
export default Chat;
