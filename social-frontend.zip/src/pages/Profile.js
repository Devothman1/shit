import React from 'react';
function Profile() {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold">Profile Page</h1>
      <p>Welcome to the Profile page of your Social App!</p>
    </div>
  );
}
export default Profile;
