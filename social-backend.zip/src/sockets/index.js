module.exports = function(io){
  io.on('connection', (socket) => {
    console.log('socket connected', socket.id);

    socket.on('join', (userId) => {
      socket.join(userId); // personal room
    });

    socket.on('send_message', async (data) => {
      // data: { from, to, text, tempId }
      // In production: save message to DB, validate, rate-limit, sanitize
      io.to(data.to).emit('new_message', data);
    });

    socket.on('disconnect', ()=> {
      console.log('socket disconnected', socket.id);
    });
  });
};
