const express = require('express');
const router = express.Router();
const Post = require('../models/Post');
const auth = require('../middlewares/auth');

// create post
router.post('/', auth, async (req,res)=>{
  const { text, media, privacy } = req.body;
  const post = new Post({ author: req.userId, text, media, privacy });
  await post.save();
  res.json({ post });
});

// get feed (very basic)
router.get('/feed', auth, async (req,res)=>{
  // simple: return recent public posts and posts by friends
  const user = req.userId;
  const posts = await Post.find({
    $or: [
      { privacy: 'public' },
      { author: { $in: (await require('../models/User').findById(user).then(u=>u.friends || [])) } }
    ]
  }).sort({ createdAt: -1 }).limit(50).populate('author','name photos');
  res.json({ posts });
});

module.exports = router;
