const express = require('express');
const router = express.Router();
const User = require('../models/User');
const auth = require('../middlewares/auth');

router.get('/me', auth, async (req,res)=>{
  const user = await User.findById(req.userId).select('-password').lean();
  res.json({ user });
});

router.get('/:id', auth, async (req,res)=>{
  const user = await User.findById(req.params.id).select('-password');
  if(!user) return res.status(404).json({ msg: 'not found' });
  res.json({ user });
});

module.exports = router;
