const express = require('express');
const router = express.Router();
const FriendRequest = require('../models/FriendRequest');
const User = require('../models/User');
const auth = require('../middlewares/auth');

// send request
router.post('/request/:to', auth, async (req,res)=>{
  const to = req.params.to;
  if(to === req.userId) return res.status(400).json({ msg: 'cannot add yourself' });
  const existing = await FriendRequest.findOne({ from: req.userId, to });
  if(existing) return res.status(400).json({ msg: 'request exists' });
  const fr = new FriendRequest({ from: req.userId, to });
  await fr.save();
  res.json({ fr });
});

// accept
router.post('/accept/:id', auth, async (req,res)=>{
  const fr = await FriendRequest.findById(req.params.id);
  if(!fr || fr.to.toString() !== req.userId) return res.status(404).json({ msg: 'not found' });
  fr.status = 'accepted';
  await fr.save();
  // add to friends lists
  await User.findByIdAndUpdate(fr.from, { $addToSet: { friends: fr.to }});
  await User.findByIdAndUpdate(fr.to, { $addToSet: { friends: fr.from }});
  res.json({ ok: true });
});

module.exports = router;
