const express = require('express');
const router = express.Router();
const Message = require('../models/Message');
const auth = require('../middlewares/auth');

// send message (store)
router.post('/send', auth, async (req,res)=>{
  const { to, text } = req.body;
  const msg = new Message({ from: req.userId, to, text });
  await msg.save();
  res.json({ msg });
});

// get conversation
router.get('/conversation/:userId', auth, async (req,res)=>{
  const other = req.params.userId;
  const msgs = await Message.find({ $or: [
    { from: req.userId, to: other },
    { from: other, to: req.userId }
  ]}).sort({ createdAt: 1 }).limit(200);
  res.json({ msgs });
});

module.exports = router;
