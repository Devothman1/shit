const express = require('express');
const router = express.Router();
const User = require('../models/User');
const auth = require('../middlewares/auth');

router.get('/', auth, async (req,res)=>{
  const q = req.query.q || '';
  if(!q) return res.json({ results: [] });
  const results = await User.find({ $text: { $search: q } }).limit(30).select('name currentCity job photos');
  res.json({ results });
});

module.exports = router;
