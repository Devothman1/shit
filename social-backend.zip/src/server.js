require('dotenv').config();
const express = require('express');
const http = require('http');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const connectDB = require('./config/db');
const authRoutes = require('./routes/auth');
const usersRoutes = require('./routes/users');
const postsRoutes = require('./routes/posts');
const friendsRoutes = require('./routes/friends');
const chatRoutes = require('./routes/chat');
const searchRoutes = require('./routes/search');

const app = express();
const server = http.createServer(app);
const io = require('socket.io')(server, { cors: { origin: '*' } });

app.use(helmet());
app.use(cors());
app.use(express.json({ limit: '5mb' }));

const limiter = rateLimit({ windowMs: 15*60*1000, max: 200 });
app.use(limiter);

app.use('/api/auth', authRoutes);
app.use('/api/users', usersRoutes);
app.use('/api/posts', postsRoutes);
app.use('/api/friends', friendsRoutes);
app.use('/api/chat', chatRoutes);
app.use('/api/search', searchRoutes);

// basic health
app.get('/api/health', (req,res)=> res.json({ status: 'ok' }));

// socket handling
const sockets = require('./sockets');
sockets(io);

const PORT = process.env.PORT || 4000;
connectDB(process.env.MONGO_URI || 'mongodb://localhost:27017/socialdb').then(()=> {
  server.listen(PORT, ()=> console.log('Server started on', PORT));
}).catch(err => {
  console.error('DB connect error', err);
  process.exit(1);
});
