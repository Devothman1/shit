const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  name: {type: String, required: true, index: true},
  email: {type: String, required: true, unique: true, lowercase: true},
  password: {type: String, required: true},
  age: Number,
  job: String,
  currentCity: String,
  location: { type: { type: String }, coordinates: [] },
  bio: String,
  photos: [String],
  friends: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  createdAt: {type: Date, default: Date.now}
});
userSchema.index({ name: 'text', currentCity: 'text', job: 'text' });

module.exports = mongoose.model('User', userSchema);
