# Social Backend (Node.js + Express + MongoDB)

Basic backend for a social/dating app: auth, users, posts, friends, chat (socket.io), notifications.

## Quick start (local with docker)
1. copy `.env.example` to `.env` and set values
2. `docker compose up --build`
3. API available at http://localhost:4000

## Scripts
- `npm run dev` (requires nodemon)
- `npm start`

## Notes
- This repository is a starting template. Add production hardening, S3 details, HTTPS, and tests before production.
